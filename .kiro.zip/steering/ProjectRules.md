---
inclusion: always
---

<context>
**Project:** 消消乐+扫雷混合游戏 (Match-3 + Minesweeper hybrid)
**Engine:** Godot 4.6.1 stable mono
**Language:** C# only

**Key Files:**
- Main Scene: `My2DMap.tscn`
- MCP Server: `Scripts/MCP/MCPServer.cs` (port 8765)
- Game State: `Scripts/MCP/GameStateCapture.cs`
- Test Scripts: `.kiro/scripts/testing/`
</context>

<completed_guides>
## 已完成任务的详细指导

以下文档位于 `C:\Godot\KiroWorkingSpace\OtherInstructions\`，包含已完成的特殊任务的完整指导：

### 动画管理
- **AnimationExport_Guide.md** - Godot动画自动导出完整指南
  - EditorScenePostImport脚本批量导出动画
  - Import Script UID问题修复方案
  - C# Export变量可视化管理
  - 类似UE的工作流程

### 输入系统
- **GodotInputMap.md** - Godot Input Map配置指南
  - 编辑器配置流程
  - 代码使用示例
  - 手柄按钮映射参考
  - 常见问题解决

**使用方式：** 遇到相关问题时，参考这些文档获取详细的解决方案和最佳实践。
</completed_guides>
